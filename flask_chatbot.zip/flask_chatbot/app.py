from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# Simple chatbot logic (could be expanded for a more advanced bot)
def chatbot_response(message):
    responses = {
        "hi": "Hello! How can I assist you today?",
        "hello": "Hi there! What can I do for you?",
        "bye": "Goodbye! Have a great day!",
    }
    return responses.get(message.lower(), "Sorry, I didn't understand that.")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_message = request.form['message']
    bot_reply = chatbot_response(user_message)
    return jsonify({'response': bot_reply})

if __name__ == '__main__':
    app.run(debug=True)
