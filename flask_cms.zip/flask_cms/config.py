import os

class Config:
    SECRET_KEY = '1bc93bc7e4b9d665f142308083daf138'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
